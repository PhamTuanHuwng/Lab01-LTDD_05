package com.example.lab_01_ltdd_04

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.lab_01_ltdd_04.databinding.ActivityMain2Binding

class MainActivity2 : AppCompatActivity() {
    lateinit var acMain2Binding: ActivityMain2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        acMain2Binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(acMain2Binding.root)

        var a = intent.getDoubleExtra("a", 0.0)
        var b = intent.getDoubleExtra("b", 0.0)
        var c = intent.getDoubleExtra("c", 0.0)
        var kqua: String? = ""

        if (a == 0.0) {
            if (b == 0.0) {
                if (c == 0.0) {
                    acMain2Binding.txtKetQua.setText("Phương trình vô số nghiệm")
                    kqua = "Phương trình vô số nghiệm"
                } else {
                    acMain2Binding.txtKetQua.setText("Phương trình vô nghiệm")
                    kqua = "Phương trình vô nghiệm"
                }
            } else {
                acMain2Binding.txtKetQua.setText("Phương trình có một nghiệm duy nhất x = ${-c / b}")
                kqua = "Phương trình có một nghiệm duy nhất x = ${-c / b}"
            }
        } else {
            var delta: Double = (b * b) - (4 * a * c)
            if (delta < 0.0) {
                acMain2Binding.txtKetQua.setText("Phương trình vô nghiệm")
                kqua = "Phương trình vô nghiệm"
            } else if (delta == 0.0) {
                acMain2Binding.txtKetQua.setText("Phương trình có một nghiệm kép x = ${-b / (2 * a)}")
                kqua = "Phương trình có một nghiệm kép x = ${-b / (2 * a)}"
            } else {
                val x1 = (-b + Math.sqrt(delta)) / (2 * a)
                val x2 = (-b - Math.sqrt(delta)) / (2 * a)
                /*
                    % : Bắt đầu một định dạng số.
                    .2 : Giữ lại 2 chữ số sau dấu thập phân.
                    f : Đại diện cho số thực (float/double).
                 */
                acMain2Binding.txtKetQua.text = ("Phương trình có 2 nghiệm phân biệt:\nx1 = %.2f" +
                        "\nx2 = %.2f").format(x1, x2)
                kqua = "Phương trình có 2 nghiệm phân biệt: " +
                        "x1 = ${(-b + Math.sqrt(delta)) / (2 * a)}, x2 = ${(-b - Math.sqrt(delta)) / (2 * a)}"
            }
        }

        acMain2Binding.btnBack.setOnClickListener {
            val returnIntent = Intent().apply {
                putExtra("kqua", kqua)
            }
            setResult(RESULT_OK, returnIntent) // Trả kết quả về MainActivity
            finish() // Đóng Activity
        }
    }
}