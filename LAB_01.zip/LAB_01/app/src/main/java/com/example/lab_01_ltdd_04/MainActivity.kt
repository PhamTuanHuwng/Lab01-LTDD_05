package com.example.lab_01_ltdd_04

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.lab_01_ltdd_04.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var acMainBinding: ActivityMainBinding
    private val activityResultLauncher =
        // Đăng ký một callback để nhận kết quả trả về từ Activity khác
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            // result có kiểu dữ liệu là ActivityResult
            if (result.resultCode == RESULT_OK) { // Kiểm tra xem kết quả có hợp lệ không

                // Lấy dữ liệu từ Intent trả về
                var kqua = result.data?.getStringExtra("kqua")

                // Hiển thị kết quả bằng Toast
                Toast.makeText(this, kqua, Toast.LENGTH_SHORT).show()
            }
        }
    /*
        layoutInflater: Là một đối tượng giúp đọc file XML và tạo View.
        ActivityMainBinding.inflate(layoutInflater):
        Dùng layoutInflater để chuyển activity_main.xml thành một cây View trong bộ nhớ.
        Trả về một đối tượng binding giúp truy cập trực tiếp các thành phần trong XML.
        setContentView(binding.root):
        Gán root view của binding làm giao diện chính của Activity.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        acMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(acMainBinding.root)

        acMainBinding.btnGiaiPT.setOnClickListener {
            var aStr = acMainBinding.edtHeSoA.text.toString()
            var bStr = acMainBinding.edtHeSoB.text.toString()
            var cStr = acMainBinding.edtHeSoC.text.toString()

            if (aStr.isEmpty() || bStr.isEmpty() || cStr.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập đầy đủ hệ số!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener // Thoát khỏi onClickListener ngay lập tức
            }

            val a = aStr.toDoubleOrNull()
            val b = bStr.toDoubleOrNull()
            val c = cStr.toDoubleOrNull()

            if (a == null || b == null || c == null) {
                Toast.makeText(this, "Vui lòng nhập số hợp lệ!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener // Thoát khỏi onClickListener ngay lập tức
            }

            var i = Intent(this,MainActivity2::class.java).apply {
                putExtra("a",a)
                putExtra("b",b)
                putExtra("c",c)
            }

            activityResultLauncher.launch(i)
        }
    }
}